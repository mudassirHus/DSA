import { defineConfig } from '@playwright/test';

export default defineConfig({
   testDir: './omni_automation_tests', // Set the root directory to include all folders
   reporter: [['list'], ['json', { outputFile: 'ztests_result/results.json' }]],
   projects: [
      {
         name: 'default',
         outputDir: 'tests_result' // Set the output folder for test results
      }
   ],
   testMatch: ['**/*.test.js']
});
