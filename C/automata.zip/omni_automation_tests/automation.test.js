import test from 'node:test';
import { expect } from 'chai';

import { given } from '../functional_primitives/bdd.js';
import {
   createDummyBatchRun,
   expectedChromiumStartsLog,
   expectedNoChromiumConfigLog,
   withMockedCreateLogger,
   withMockedInitializeLogger,
   inMemLogger
} from './automation-test-helper.js';

import automationResult from '../omni_constants/automation-result.js';

// 🟢 Given batchRun and a logger which fails during initialization
// 🔵 When automation runs
// ❌ Then all products of batchrun will fail
test('Fails when logger initialization fails', { concurrent: false }, async () => {
   let batchRun;
   let automation;

   return given(async () => {
      batchRun = createDummyBatchRun();
      automation = await withMockedInitializeLogger();
   }).when(async () => {
      await automation(batchRun);
   }).then(() => {
      const allFailed = batchRun.batchProducts.every(p => p.status === automationResult.failure);
      expect(allFailed).to.be.true;
   });
});

test('Fails when chromium config is not found', { concurrent: false }, async () => {
   let batchRun;
   let automation;
   try {
      await given(async () => {
         batchRun = createDummyBatchRun({ databaseId: -99 });
         ({automation} = await withMockedCreateLogger());
      }).when(async () => {
         await automation(batchRun);
      }).then(() => {
         const allFailed = batchRun.batchProducts.every(p => p.status === automationResult.failure);
         expect(allFailed).to.be.true;
         expect(inMemLogger.getLogs()).to.equal(expectedNoChromiumConfigLog);
      });
   } catch (error) {
      console.error(error);
   }
});
test('check logs', { concurrent: false }, async () => {
   let batchRun = createDummyBatchRun();
   let automation = await withMockedCreateLogger();
   await automation(batchRun);
});
// test('succeeds when chromium config is found', { concurrent: false }, async () => {
//    let batchRun;
//    let automation;
//    let actualLog;

//    given(() => {
//       fs.writeFileSync('./app.log', '');
//       batchRun = createDummyBatchRun({ databaseId: 2 });
//    });

//    given(async () => {
//       automation = (await esmock('../omni_automation/automation.js')).automation;
//    });

//    when(async () => {
//       await automation(batchRun);
//       actualLog = fs.readFileSync('./app.log', 'utf8');
//    });

//    then(() => {
//       const allSuccess = batchRun.batchProducts.every(
//          p => p.status === automationResult.success
//       );
//       expect(allSuccess).to.be.true;
//       expect(actualLog).to.equal(expectedChromiumStartsLog);
//    });
// });
