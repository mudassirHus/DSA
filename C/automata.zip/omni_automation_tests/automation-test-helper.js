import automationResult from '../omni_constants/automation-result.js';
import batchProduct from '../value_objects/batch-product.js';
import esmock from 'esmock';
import Writable from 'stream';
import pino from 'pino';
import { ok } from '../functional_primitives/core.js';

export function createDummyBatchRun({databaseId} = {})
{
   return {
      databaseId,
      batchProducts: [
         batchProduct(1, 10, 'Equity Product 1', 'Equity Vehicle 1', automationResult.success),
         batchProduct(2, 20, 'Equity Product 2', 'Equity Vehicle 2', automationResult.success),
         batchProduct(3, 30, 'Equity Product 3', 'Equity Vehicle 3', automationResult.success),
         batchProduct(4, 40, 'Equity Product 4', 'Equity Vehicle 4', automationResult.success)
      ]
   };
}


export function createInMemoryPinoLogger()
{
   let logs = '';
   const stream = new Writable({
      write(chunk, encoding, cb) {
         logs += chunk.toString();
         cb();
      }
   });

   const logger = pino(stream);

   // Return both logger and accessor
   return {
      logger,
      getLogs: () => logs
   };
};
export let inMemLogger;
export async function withMockedCreateLogger()
{
   const {automation} = await esmock('#automation/automation.js', {
      '#automation/logger/logger.js': {
         initializeLogger: () => {
            inMemLogger = createInMemoryPinoLogger();
            return ok(inMemLogger.logger);
         }
      }
   });
   return {automation};
}
export async function withMockedInitializeLogger()
{
   const {automation} = await esmock('#automation/automation.js', {
      '#automation/logger/logger.js': {
         initializeLogger: async () => ({ ok: false, error: 'Failed to initialize pino logger: boom' })
      }
   });
   return automation;
}

export const expectedNoChromiumConfigLog = `{"level":30,"msg":"Start - Transaction"}
{"level":50,"msg":"No chromium configuration found for databaseId: -99"}
{"level":30,"msg":"Finished - Transaction"}
`;

export const expectedChromiumStartsLog = `{"level":30,"msg":"Start - Transaction"}
{"level":30,"hostname":"mudh","osType":"Windows_NT","browserVersion":"139.0.7258.5","pageTimeout":10000,"navigationTimeout":10000}
{"level":30,"msg":"Automation Resources Closed"}
{"level":30,"msg":"Finished - Transaction"}
`;

