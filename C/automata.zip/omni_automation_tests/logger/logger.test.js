import test from 'node:test';
import esmock from 'esmock';
import { expect } from 'chai';

test('when logger initialize fails', async () => {
   const { initializeLogger } = await withMockedLogger();
   const loggerResult = await initializeLogger();
   expect(loggerResult.error).to.contain('Failed to initialize pino logger');
});

async function withMockedLogger()
{
   const fakeCreatePinoLogger = { createPinoLogger: () => { throw new Error('boom'); } };
   return await esmock('#automation/logger/logger.js', {
      '#automation/logger/create-logger.js': fakeCreatePinoLogger
   });
}
