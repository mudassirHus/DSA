export const given = (fn) => {
   return {
      when: (whenFn) => {
         return {
            then: async (thenFn) => {
               await fn();
               await whenFn();
               await thenFn();
            }
         };
      }
   };
};
