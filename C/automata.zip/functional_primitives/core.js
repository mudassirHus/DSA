import automationResult from '../omni_constants/automation-result.js';

export const ok = (value) => ({
   status: automationResult.success,
   value,
   ok: true
});
export const err = (error) => ({
   status: automationResult.failure,
   error,
   ok: false
});

export const whenOk = (result, fn) => { 
   if(result.ok) fn(); 
};
export const whenErr = (result, fn) => {
   if(!result.ok) fn();
};

export const match = (result, { ok, err }) => result.ok ? ok(result.value) : err(result.error);
export const matchAsync = async (result, { ok, err }) => result.ok ? await ok(result.value) : await err(result.error);

export const pipe = async (initialFn, ...fns) => {
   let result = initialFn();
   if (!result.ok) return result;

   for (const fn of fns) {
      result = fn(result.value);
      if (!result.ok) return result;
   }
   return result;
};
export const pipeAsync = async (initialFn, ...fns) => {
   let result = await initialFn();
   if (!result.ok) return result;

   for (const fn of fns) {
      result = await fn(result.value);
      if (!result.ok) return result;
   }
   return result;
};
