import {ok, err, match} from '../../functional_primitives/core.js';
import {createPinoLogger} from './create-logger.js';

export function initializeLogger()
{
   try {
      const logger = createPinoLogger();
      return ok(logger);
   } catch (error) {
      return err(`Failed to initialize pino logger: ${error}`);
   }
}

export async function warpInLogger(logger, label, fn)
{
   logger.info(`Start - ${label}`);
   try {
      const result = await fn(); // run your pipeline
      match(result, {
         ok: (result) => logger.info(result),
         err: (error) => logger.error(error)
      });
      logger.info(`Finished - ${label}`);
      return result;
   } catch (error) {
      logger.error(error);
      logger.info(`Finished - ${label}`);
      return err(error);
   }
}
