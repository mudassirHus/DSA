import pino from 'pino';

export const createPinoLogger = () => pino({base: undefined, timestamp: false}, pino.destination({ dest: './app.log', sync: true }));
