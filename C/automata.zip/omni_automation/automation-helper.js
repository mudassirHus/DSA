import playwright from 'playwright';
import os from 'node:os';
import { ok, err } from '../functional_primitives/core.js';

export async function initializeBrowser(config, logger)
{
   let browser, context, page;
   try {
      const { launchConfig, contextConfig, pageTimeout, navigationTimeout } = config;

      browser = await playwright.chromium.launch(launchConfig);
      context = await browser.newContext(contextConfig);
      page = await context.newPage();

      page.setDefaultTimeout(pageTimeout);
      page.setDefaultNavigationTimeout(navigationTimeout);

      logger.info({
         hostname: os.hostname(),
         osType: os.type(),
         browserVersion: browser.version(),
         pageTimeout,
         navigationTimeout
      });
      
      return ok({ browser, context, page });
   } catch (error) {
      await closeResources(page, context, browser);
      return err(`Failed to initialize browser: ${error}`);
   }
}

export async function closeResources(page, context, browser)
{
   if(page) await page.close();
   if(context) await context.close();
   if(browser) await browser.close();
      
   return ok('Automation Resources Closed');
}
