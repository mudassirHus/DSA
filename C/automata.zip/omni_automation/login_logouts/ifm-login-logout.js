function login(page)
{
   let ignore = page.url;
   return ignore + 'Run informa login automation';
}

function logout(page)
{
   let ignore = page.url;
   return ignore + 'Run informa logout automation';
}
export default {
   login,
   logout
};
