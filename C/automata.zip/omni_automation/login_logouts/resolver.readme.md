# 🔐 Login/Logout Module Resolver

This module maps a `databaseId` to its corresponding login/logout automation module filename.

## 📁 Required Naming Format

All login/logout modules **must follow** this filename convention:

```
<databaseCode>-login-logout.js
```

✅ Examples:
- `cln-login-logout.js`
- `wsr-login-logout.js`

⚠️ **Incorrect naming will break the dynamic import system.**

## 🧠 Developer Note

Ensure that:
- The filename **matches** the mapping in the resolver.
- New database codes are added with the correct filename in the resolver map.

## ⚙️ Usage

```js
import resolveModule from './resolver.js';
const file = resolveModule(databaseId);
const module = await import(`./login_logouts/${file}`);
await module.login(page);
```