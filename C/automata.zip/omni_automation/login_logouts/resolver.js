import { ok, err, pipeAsync } from '../../functional_primitives/core.js';
import dbMap from '../../omni_constants/databases.js';

/**
 * The function resolves the login/logout module filename based on the database ID.
 * otherwise, the code will be unable to resolve the correct login/logout module filename.
 * All files must follow (databaseCode-login-logout.js) naming convention.
 * It is most important that developers ensure that the files reflect the correct database code.
 */
function getFileName(databaseId)
{
   const dbCode = dbMap[databaseId];
   return dbCode
      ? ok(`${dbCode}-login-logout`)
      : err(`No login/logout file found for database ID: ${databaseId}`);
}
async function importLoginLogoutModule(fileName)
{
   try {
      const loginLogoutModule = await import(`./${fileName}.js`);
      return ok(loginLogoutModule);
   }catch(error){
      return err(`Could not import LoginLogout module with fileName: ${fileName} - ${error}`);
   }
}
export default async function getLoginLogoutModuleAsync(databaseId)
{
   return await pipeAsync(
      () => getFileName(databaseId),
      (fileName) => importLoginLogoutModule(fileName)
   );
}
