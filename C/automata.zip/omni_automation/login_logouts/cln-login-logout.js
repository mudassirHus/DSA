function login(page)
{
   let ignore = page.url;
   return ignore + 'Run informa callan automation';
}

function logout(page)
{
   let ignore = page.url;
   return ignore + 'Run informa callan automation';
}
export default {
   login,
   logout
};
