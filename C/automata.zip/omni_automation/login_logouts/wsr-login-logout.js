import secrets from '../../secrets.json';

export async function wilshireLogin(page)
{
   try {
      await page.goto(secrets.wilshire.url);
      await page.fill('#MainContent_LoginUser_UserName', secrets.wilshire.username);
      await page.fill('#MainContent_LoginUser_Password', secrets.wilshire.password);
   } catch (error) {
      console.error('Error logging into Wilshire:', error);
   }
}

export async function wilshireLogout(page)
{
   await page.click('#LoginContent_LoginView1_HeadLoginStatus');
}
