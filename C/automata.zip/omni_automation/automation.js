import getChromiumConfig from '../chromium_configs/index.js';
import automationResult from '../omni_constants/automation-result.js';
import { pipeAsync, matchAsync, whenErr } from '../functional_primitives/core.js';
import { initializeLogger, warpInLogger } from './logger/logger.js';
import { initializeBrowser, closeResources } from './automation-helper.js';

export async function automation(batchRun)
{
   let loggerResult = await initializeLogger();
   await matchAsync(loggerResult, {
      ok: async (logger) => {
         const result = await warpInLogger(logger, 'Transaction', async() => await initiateAutomation(batchRun, logger));
         whenErr(result, () => batchRun.batchProducts.forEach(p => p.status = automationResult.failure));  
      },
      err: (error) => {
         console.error(error);
         batchRun.batchProducts.forEach(p => p.status = automationResult.failure);
      }
   });
}
async function initiateAutomation(batchRun, logger)
{
   const result = await pipeAsync(
      () => getChromiumConfig(batchRun.databaseId),
      async (config) => await initializeBrowser(config, logger),
      async (chromium) => await closeResources(chromium.page, chromium.context, chromium.browser)
   );
   return result;
}

