import { ONE_MINUTE, toMilliseconds } from '../omni_constants/seconds.js';

export default Object.freeze({
   name: 'default',
   databaseId: -1,
   launchConfig: {
      headless: false // Run browser in headless mode
      //args: ['--disable-dev-shm-usage'] // Additional Chromium arguments
      // downloadsPath : './downloads', // Path to save downloaded files
      // executablePath : '/path/to/chromium', // Path to the Chromium executable
      // slowMo : 50 // Slow down operations by 50ms for debugging
      // tracesDir : './traces', // Directory to save traces for debugging
   },
   contextConfig: {
      viewport: { width: 1920, height: 1080 },
      deviceScaleFactor: 1,
      isMobile: false,
      hasTouch: false,
      ignoreHTTPSErrors: true
      // recordVideo: { dir: './videos' }
   },
   pageTimeout: toMilliseconds(ONE_MINUTE),
   navigationTimeout: toMilliseconds(ONE_MINUTE)
});
