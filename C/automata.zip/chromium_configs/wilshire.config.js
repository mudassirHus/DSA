import { TEN_SECONDS, toMilliseconds } from '../omni_constants/seconds.js';

export default Object.freeze({
   name: 'wilshire',
   databaseId: 2,
   launchConfig: {
      headless: false
   },
   contextConfig: {
      viewport: { width: 1280, height: 720 },
      deviceScaleFactor: 1,
      isMobile: false,
      hasTouch: false
   },
   pageTimeout: toMilliseconds(TEN_SECONDS),
   navigationTimeout: toMilliseconds(TEN_SECONDS)
});
