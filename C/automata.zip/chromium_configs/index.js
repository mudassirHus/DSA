import defaultConfig from './default.config.js';
import wilshireConfig from './wilshire.config.js';
import { ok, err } from '../functional_primitives/core.js';

const configs = [
   defaultConfig, // Default configuration for most databases
   wilshireConfig // wilshire configuration
];

export default (databaseId) => {
   const config = configs.find((cfg) => cfg.databaseId === databaseId);
   return config ? ok(config) : err(`No chromium configuration found for databaseId: ${databaseId}`);
};
