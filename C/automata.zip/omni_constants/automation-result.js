export default Object.freeze({
   undefined: 0,
   queued: 1,
   running: 2,
   failure: 10,
   partial: 11,
   success: 12,
   clientActionNeeded: 13,
   closed: 14,
   notCollected: 15,
   noData: 16
});

