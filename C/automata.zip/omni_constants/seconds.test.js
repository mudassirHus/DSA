import test from 'node:test';
import { expect } from 'chai';
import { ONE_SECOND, ONE_MINUTE, toMilliseconds } from '../omni_constants/seconds.js';

test('Time duration constants', () => {
   expect(ONE_SECOND).to.equal(1);
   expect(ONE_MINUTE).to.equal(60);
});

test('toMilliseconds with invalid input', () => {
   expect(() => toMilliseconds('2.0')).to.throw(
      'Invalid input: "seconds" must be a integer.'
   );
   expect(() => toMilliseconds('abc')).to.throw(
      'Invalid input: "seconds" must be a integer.'
   );
   // eslint-disable-next-line custom/no-hardcoded-toMilliseconds
   expect(() => toMilliseconds(2.5)).to.throw(
      'Invalid input: "seconds" must be a integer.'
   );
   expect(() => toMilliseconds(null)).to.throw(
      'Invalid input: "seconds" must be a integer.'
   );
   expect(() => toMilliseconds(undefined)).to.throw(
      'Invalid input: "seconds" must be a integer.'
   );
});

test('toMilliseconds with valid input', () => {
   // eslint-disable-next-line custom/no-hardcoded-toMilliseconds
   expect(toMilliseconds(2)).to.equal(2000);
   // eslint-disable-next-line custom/no-hardcoded-toMilliseconds
   expect(toMilliseconds(0)).to.equal(0);
});
