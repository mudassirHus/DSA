export const automationType = {
   discovery: 'discovery',
   population: 'population',
   audit: 'audit'
};

Object.freeze(automationType);

export default automationType;

