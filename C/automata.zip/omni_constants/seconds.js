/**
 * Time Duration Constants
 * 
 * This module provides standardized time duration constants to ensure consistency
 * across the entire codebase. Using these constants helps eliminate magic numbers
 * and makes time-based operations more predictable and maintainable.
 * 
 * All Omni development teams should use these constants for any time-related logic.
 * Using Hardcoded values will result in declining of the code reviews/build failures.
 */

// =============================================================================
// BASIC TIME UNITS (in seconds)
// =============================================================================
export const ONE_SECOND = 1;
export const TWO_SECONDS = 2;
export const FIVE_SECONDS = 5;
export const TEN_SECONDS = 10;
export const FIFTEEN_SECONDS = 15;
export const THIRTY_SECONDS = 30;
export const FOURTY_FIVE_SECONDS = 45;
export const ONE_MINUTE = 60;
export const TWO_MINUTES = 120;

/**
 * Converts seconds to milliseconds.
 * @param {number} seconds - The number of seconds to convert. Must be a integer.
 * @returns {number} The equivalent time in milliseconds.
 * @throws {Error} If the input is not a valid integer.
 */
export const toMilliseconds = (seconds) => {
   if (Number.isInteger(seconds)) return seconds * 1000;
   throw new Error('Invalid input: "seconds" must be a integer.');
};

