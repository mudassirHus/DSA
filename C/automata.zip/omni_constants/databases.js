export default Object.freeze({
   1: 'cln',
   2: 'wsr',
   3: 'prq',
   4: 'ifm'
});
