export default {
  meta: {
    type: 'layout',
    docs: {
      description: 'Custom brace style: new line for function declarations, 1TBS for control statements'
    },
    fixable: 'whitespace',
    schema: []
  },

  create(context) {
    const sourceCode = context.getSourceCode();

    // 1️⃣ Enforce brace on new line for FunctionDeclaration
    function checkFunctionDeclaration(node) {
      const openingBrace = sourceCode.getFirstToken(node.body);
      const tokenBefore = sourceCode.getTokenBefore(openingBrace);

      if (!openingBrace || !tokenBefore) return;

      const sameLine = openingBrace.loc.start.line === tokenBefore.loc.end.line;

      if (sameLine) {
        context.report({
          node,
          message: 'Function opening brace must be on a new line.',
          fix(fixer) {
            return fixer.replaceTextRange(
              [tokenBefore.range[1], openingBrace.range[0]],
              '\n'
            );
          }
        });
      }
    }

    // 2️⃣ Enforce brace on the same line for control blocks (1TBS)
    function checkControlStructure(node, blockNode = node.consequent || node.body || node.block) {
      if (!blockNode || blockNode.type !== 'BlockStatement') return;

      const openingBrace = sourceCode.getFirstToken(blockNode, {
        filter: (t) => t.value === '{'
      });
      const tokenBefore = sourceCode.getTokenBefore(openingBrace);

      if (!openingBrace || !tokenBefore) return;

      const differentLine = openingBrace.loc.start.line !== tokenBefore.loc.end.line;

      if (differentLine) {
        context.report({
          node,
          message: 'Opening brace must be on the same line for control statements (1TBS).',
          fix(fixer) {
            return fixer.replaceTextRange(
              [tokenBefore.range[1], openingBrace.range[0]],
              ' '
            );
          }
        });
      }
    }

    return {
      FunctionDeclaration: checkFunctionDeclaration,
      IfStatement: checkControlStructure,
      ForStatement: checkControlStructure,
      WhileStatement: checkControlStructure,
      DoWhileStatement: checkControlStructure,
      WithStatement: checkControlStructure,
      SwitchStatement: checkControlStructure,
      TryStatement(node) {
        checkControlStructure(node, node.block);
        if (node.handler) checkControlStructure(node.handler, node.handler.body);
        if (node.finalizer) checkControlStructure(node, node.finalizer);
      }
    };
  }
};
