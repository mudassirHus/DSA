/**
 * Custom ESLint Rule: Enforce Naming Conventions
 *
 * This rule enforces consistent naming conventions:
 * - Identifiers can be either camelCase or UPPER_SNAKE_CASE.
 * - It does not enforce exclusivity between constants and functions.
 *
 * Usage:
 * - Add this rule to your ESLint configuration under the `rules` section.
 * - Example:
 *   {
 *     "custom/enforce-camelcase": "error"
 *   }
 * This rule helps maintain a consistent and readable codebase by enforcing uniform naming conventions.
 */
export default {
    meta: {
        type: 'suggestion', // This is a suggestion rule
        docs: {
            description: 'Enforce camelCase for function names and UPPER_SNAKE_CASE for constants',
            category: 'Stylistic Issues',
            recommended: false,
        },
        schema: [], // No options for this rule
        messages: {
            camelCase: 'Identifier "{{ name }}" is not in camelCase.',
            upperSnakeCase: 'Constant "{{ name }}" is not in UPPER_SNAKE_CASE.',
        },
    },
    create(context) {
        return {
            VariableDeclarator(node) {
                const name = node.id.name;

                // Check if the variable is a constant (all uppercase with underscores)
                if (/^[A-Z_][A-Z0-9_]*$/.test(name)) {
                    return; // Valid constant
                }

                // Check if the variable is in camelCase
                if (!/^[a-z][a-zA-Z0-9]*$/.test(name)) {
                    context.report({
                        node,
                        messageId: 'camelCase',
                        data: { name },
                    });
                }
            },
            FunctionDeclaration(node) {
                const name = node.id.name;

                // Check if the function name is in camelCase
                if (!/^[a-z][a-zA-Z0-9]*$/.test(name)) {
                    context.report({
                        node,
                        messageId: 'camelCase',
                        data: { name },
                    });
                }
            },
        };
    },
};