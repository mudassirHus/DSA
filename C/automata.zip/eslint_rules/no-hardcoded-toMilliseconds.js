/**
 * Custom ESLint Rule: Disallow Hardcoded Values in toMilliseconds()
 *
 * This rule disallows the use of hardcoded numeric values as arguments
 * in `toMilliseconds()` calls. Developers must use constants (e.g., ONE_SECOND, ONE_MINUTE)
 * from `seconds.js` instead.
 *
 * Usage:
 * Add "custom/no-hardcoded-toMilliseconds": "error" to your ESLint configuration.
 */

export default {
    meta: {
        type: 'problem', // This is a problem rule
        docs: {
            description: 'Disallow hardcoded numeric values in toMilliseconds() calls',
            category: 'Best Practices',
            recommended: false,
        },
        schema: [], // No options for this rule
        messages: {
            noHardcodedValues: 'Use constants (e.g., ONE_SECOND, ONE_MINUTE) from seconds.js instead of hardcoded numeric values in toMilliseconds().',
        },
    },
    create(context) {
        return {
            CallExpression(node) {
                // Check if the function being called is `toMilliseconds`
                if (node.callee.name === 'toMilliseconds') {
                    const argument = node.arguments[0];

                    // Check if the argument is a numeric literal
                    if (argument && argument.type === 'Literal' && typeof argument.value === 'number') {
                        context.report({
                            node: argument,
                            messageId: 'noHardcodedValues',
                        });
                    }
                }
            },
        };
    },
};