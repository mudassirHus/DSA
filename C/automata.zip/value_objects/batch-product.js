export default function batchProduct(omniProductId, omniVehicleId, databaseProductName, databaseVehicleName, status)
{
   return {
      omniProductId,
      omniVehicleId,
      databaseProductName,
      databaseVehicleName,
      status
   };
}
