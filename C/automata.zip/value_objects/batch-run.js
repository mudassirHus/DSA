export default function batchRun(automationType, firmId, databaseId, transactionId, runId, batchProducts)
{
   return {
      automationType,
      firmId,
      databaseId,
      transactionId,
      runId,
      batchProducts
   };
}
