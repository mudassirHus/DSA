import unicorn from 'eslint-plugin-unicorn';
import importPlugin from 'eslint-plugin-import';
import noHardcodedToMilliseconds from './eslint_rules/no-hardcoded-toMilliseconds.js';
import enforceCamelCase from './eslint_rules/enforce-camelcase.js';
import linusTorvaldsStyleBracing from './eslint_rules/linus-torvalds-style-bracing.js';

export default [
   {
      ignores: ['node_modules', 'tests_result', 'eslint_rules'] // Ignore configuration files and directories
   },
   {
      files: ['**/*.js'], // Apply to all JavaScript files
      languageOptions: {
         ecmaVersion: 'latest', // Use the latest ECMAScript version
         sourceType: 'module', // Use ES modules
         globals: {
            console: 'readonly'
         }
      },
      plugins: {
         unicorn, // Add the Unicorn plugin
         import: importPlugin, // Add the Import plugin
         custom: {
            rules: {
               'no-hardcoded-toMilliseconds': noHardcodedToMilliseconds,
               'enforce-camelcase': enforceCamelCase,
               'linus-torvalds-style-bracing': linusTorvaldsStyleBracing
            }
         }
      },
      rules: {
         'indent': ['error', 3], // Enforce 3 spaces for indentation
         'quotes': ['error', 'single'], // Enforce single quotes
         'semi': ['error', 'always'], // Enforce semicolons
         'no-unused-vars': ['error'], // Warn about unused variables
         'no-undef': 'error', // Disallow undefined variables
         'eqeqeq': ['error', 'always'], // Require strict equality (===)
         'eol-last': ['error', 'always'], // Enforce newline at the end of files
         'linebreak-style': ['error', 'unix'], // Enforce LF line endings
         'no-multiple-empty-lines': ['error', { max: 1 }], // Limit empty lines
         'space-in-parens': ['error', 'never'], // Disallow spaces inside parentheses
         'key-spacing': ['error', { beforeColon: false, afterColon: true }], // Enforce space after colon in objects
         'space-infix-ops': ['error'], // Require spaces around operators (e.g., `=`, `+`, etc.)
         'no-multi-spaces': ['error'], // Disallow multiple spaces
         'comma-dangle': ['error', 'never'], // Disallow trailing commas
         'import/no-unresolved': 'error', // Ensure imports can be resolved
         'import/no-named-as-default-member': 'error', // Disallow named exports as default members
         'custom/no-hardcoded-toMilliseconds': 'error', // Enable the custom rule
         'custom/enforce-camelcase': 'error', // Enable the custom rule
         'custom/linus-torvalds-style-bracing': 'error', // Enable the custom rule
         'no-restricted-syntax': [
            'error',
            {
               selector: 'ClassDeclaration',
               message: 'Classes are not allowed. Use Pure Functional Programming instead. We spent decade with selenium C# with deep inheritance which is hard to maintain and gives lot of power to abuse that feature.'
            }
         ],
         'unicorn/filename-case': [
            'error',
            {
               case: 'kebabCase' // Enforce kebab-case for filenames
            }
         ]
      }
   }
];
